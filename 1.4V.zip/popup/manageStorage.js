function verifyLocalMemory(){
	
	var emaiStored = localStorage.getItem("ssoEm");
	if(typeof emaiStored !== 'undefined' && emaiStored !== null){
		initializeFirstLoad();
	}
	else{
		hideMailDiv();
		//initializeFirstLoad();
	}
}
function setEmail(em_text) {
  localStorage.setItem('ssoEm', em_text);
}
(function () {'use strict';// this function is strict...
}());
//Global Variables-Start
var status_open = "Y";
var srNumber = "";
var status_new = "N";
var proj_available = "Y";
var getSR = "";
var updateSR = "";
var createSR = "";
var getProject = "";
var srInformation = "";
var validInternet = "";
var csiNum = "";
//Global Variables-End

/* Error Handling */
function errorToggle() {

	document.getElementById("form_container").style.display = "none";
	document.getElementById("error_content").style.display = "block";
}
document.addEventListener("DOMContentLoaded", function (event) {
	document.getElementById("btnOKServerError").addEventListener("click", function( event ) {
		document.getElementById("hover_bkgr_fricc_error").style.display = "none";
		window.close(); //Close the popup
	}, false);
});
// When the Firefox Addon is loaded 
window.addEventListener("load", populateSRNumber);
function populateSRNumber() {
	getURLFromFile();
	/* Check Internet Connection & VPN */
	doesConnectionExist();
	/* */
	
	/* Hide Unwanted Sections On Page Load */
	document.getElementById("hover_bkgr_fricc_error").style.display = "none"; //Timeout Error
	document.getElementById("projDiv").style.display = "none"; //Project List
	document.getElementById("loader").style.display = "none"; //Loader
	document.getElementById("lblSRClose1").style.display = "none";
	/* */

	browser.tabs.query({
		active: true,
		currentWindow: true
	}).then(function (tabs) {
		var currentTabUrl = tabs[0].url;
		var url = new URL(currentTabUrl);
		var domain = url.hostname;
		if (domain === ("support.us.oracle.com") && ((url.toString().indexOf("https://support.us.oracle.com/oip/faces/secure/srm/srview/SRTechnical.jspx?action=createQueryTab&srNumber=") > -1) ||(url.toString().indexOf("https://support.us.oracle.com/oip/faces/secure/srm/srview/SRTechnical.jspx?srNumber=")> -1 ))){ //Execute the rest of the plugin code only when user is MOS site
			srNumber = url.searchParams.get("srNumber");
			var inputBoxSRNum = document.getElementById("element_1"); // Set the SR Number Parameter to the SR Input Textbox on form.
			inputBoxSRNum.value = srNumber;
			verifyLocalMemory();	
			var em= localStorage.getItem("ssoEm");
			console.log("em:"+em);
			if (srNumber !== "" && (typeof em !== 'undefined' && em !== null)){
				getURLFromFile();
				getSRUpdateFromImplPortal();
			}
			else{
				initializeFirstLoad();
			}
		}
		else { //Error Handling
			document.getElementById("form_container").style.display = "none";
			document.getElementById("initialize_user").style.display = "none";
			document.getElementById("error_content").style.display = "block"; //Display Error Message
		}
	});
}
//Function to fetch existing SR Update from implementation portal
function getSRUpdateFromImplPortal() {
	console.log('getSRUpdateFromImplPortal');	
	var url = getSR + srNumber;
	const xhr = new XMLHttpRequest();
	xhr.timeout = 5000;
	xhr.onreadystatechange = function (e) {
		if (xhr.readyState === 4) {
			if (xhr.status === 200) {
				var responseText = JSON.parse(xhr.responseText);
				var srCount = Object.keys(responseText.items).length;
				if(srCount > 0){ //SR exists in Portal
					var isSROpenInPortal = responseText.items[0].is_open;
					var portalUpdate = responseText.items[0].issue_detail;
					// If SR Is Open
					if (isSROpenInPortal === "Y"){
						document.getElementById("srStatusSelect").value = "Open"
					} 
					else{
						document.getElementById("srStatusSelect").value = "Closed"
					}
					if (portalUpdate !== "") {
						document.getElementById("element_2").value = portalUpdate.replace(/<br ?\/?>/g, "\n"); //Replacing Breaks with JS equivalent
					}
				} 
				else { //No SR Found in Portal, simulating new SR flow
					newSRFlow();
				}
			} 
		}
	};
	xhr.ontimeout = function () {
		document.getElementById("hover_bkgr_fricc_error").style.display = "block";
	};
	xhr.open("get", url, true);
	xhr.send();
}
//Code To Handle SR Status	
document.addEventListener("DOMContentLoaded", function (event) {
	var a = document.getElementById('srStatusSelect');
	a.addEventListener('change', function() {
		if(this.value =="Closed"){//Closed
				document.getElementById("saveForm").value = "Close SR"
				document.getElementById("projDiv").style.display = "None";
				document.getElementById("srSummary").style.display = "none";
				document.getElementById("lblSRUpd1").style.display = "none";
				document.getElementById("lblSRClose1").style.display = "block";
				status_open = "N";
		}
		if(this.value =="Open"){//Open
				document.getElementById("saveForm").value = "Update SR"
				document.getElementById("projDiv").style.display = "None";
				document.getElementById("srSummary").style.display = "none";
				document.getElementById("lblSRClose1").style.display = "none";
				document.getElementById("lblSRUpd1").style.display = "block";
				status_open = "Y";
				status_new = "N";
		}
		if(this.value =="New"){//New
				newSRFlow();
		}  
	}, false);
});
document.addEventListener("submit", (e) => { //When Firefox addon is submit 
	document.getElementById("form_container").style.display = "none";
	document.getElementById("loader").style.display = "block";
	if (document.getElementById("element_2").value !== "") {
		if (status_new == "Y" && proj_available == "N") {
			window.alert("Project Name Is Required");
			document.getElementById("loader").style.display = "none";
			document.getElementById("form_container").style.display = "block";
		}
		//If SR is OPEN
		if (status_open == "Y" && status_new == "N" && proj_available == "Y") {
			var srNum = document.getElementById("element_1").value;
			var srUpdate = document.getElementById("element_2").value.replace(/\n/g, "<br />");
			var invocation = new XMLHttpRequest();
			var url = updateSR;
			if (invocation) {
				invocation.open("POST", url, true);
				invocation.timeout = 5000;
				invocation.setRequestHeader("sr_number", srNum); //Send SR Number
				invocation.setRequestHeader("comment", srUpdate); //Send the SR Update
				invocation.setRequestHeader("is_open", status_open); //Send the Status of the SR
				invocation.withCredentials = true;
				invocation.send();
				invocation.onreadystatechange = function (e) {
					if (invocation.readyState === 4) {
						if (invocation.status === 200) {
							document.getElementById("loader").style.display = "none";
							document.getElementById("form_container").style.display = "block";
							window.alert("SR Updated In Portal");
							window.close(); //Close the popup
						}
					}
				};
			}
		}
		//If SR is Closed
		if (status_open == "N" && status_new == "N") {
			var srNum = document.getElementById("element_1").value;
			var srUpdate = document.getElementById("element_2").value.replace(/\n/g, "<br />");
			var invocation = new XMLHttpRequest();
			var url = updateSR;
			if (invocation) {
				invocation.open("POST", url, true);
				invocation.timeout = 5000;
				invocation.setRequestHeader("sr_number", srNum); //Send SR Number
				invocation.setRequestHeader("comment", srUpdate); //Send the SR Update
				invocation.setRequestHeader("is_open", status_open); //Send the Status of the SR
				invocation.withCredentials = true;
				invocation.send();
				invocation.onreadystatechange = function (e) {
					if (invocation.readyState === 4) {
						if (invocation.status === 200) {
							document.getElementById("loader").style.display = "none";
							document.getElementById("form_container").style.display = "block";
							window.alert("SR Closed In Portal");
							window.close(); //Close the popup
						}
					}
				};
			}
		}
		//If SR is a NEW SR
		if (status_open == "N" && status_new == "Y" && proj_available == "Y") {
			console.log('Inside New SR Create Flow');
			var srSummary = document.getElementById("summaryTxt").value;
			var srUpdate = document.getElementById("element_2").value.replace(/\n/g, "<br />");
			var srNum = document.getElementById("element_1").value;
			var projectName = document.getElementById("projName").value;
			var invocation = new XMLHttpRequest();
			var url = createSR;
			if (invocation) {
				invocation.open("POST", url, true);
				invocation.timeout = 5000;
				invocation.setRequestHeader("project", projectName); //Set Project Name
				invocation.setRequestHeader("sr_number", srNum); //Set the SR Number
				invocation.setRequestHeader("summary", srSummary); //Set the SR Update
				invocation.setRequestHeader("is_open", "Y"); //Set the SR open in Portal
				invocation.setRequestHeader("comments", srUpdate); //Set SR Summary
				invocation.withCredentials = true;
				invocation.send();
				invocation.onreadystatechange = function (e) {
					if (invocation.readyState === 4) {
						if (invocation.status === 200) {
							console.log('200');
							document.getElementById("loader").style.display = "none";
							document.getElementById("form_container").style.display = "block";
							window.alert("SR Created In Portal");
							window.close(); //Close the popup
						}
					}
				};
			}
		}
	} //If end
	else {
		window.alert("Please provide a SR update before clicking Submit");
	}
	e.preventDefault(); // Stop the OnLoad function to execute on Submit.
});
//Retrieve the Endpoints
function getURLFromFile() {
	console.log('getURLFromFile');
	var xhr = new XMLHttpRequest();
	xhr.overrideMimeType("application/json");
	xhr.onreadystatechange = function () {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var responseText = JSON.parse(xhr.responseText);
				getSR = responseText.getSR;
				updateSR = responseText.updateSR;
				createSR = responseText.createSR;
				getProject = responseText.getProject;
			} else {
				document.getElementById("hover_bkgr_fricc_error").style.display = "block";
			}
		}
	}
	xhr.open("GET", browser.extension.getURL('/popup/url.json'), true);
	xhr.send();
}
function doesConnectionExist() {
	console.log('doesConnectionExist');
    var xhr = new XMLHttpRequest();
    var file = "https://support.us.oracle.com/";
    xhr.open('GET', file, true);
    xhr.send();
    xhr.addEventListener("readystatechange", processRequest, false);
    function processRequest(e) {
      if (xhr.readyState == 4) {
        if (xhr.status >= 200 && xhr.status < 304) {
          validInternet = "true";
        } else {
		    document.getElementById("form_container").style.display = "none";
			document.getElementById("initialize_user").style.display = "none";
			document.getElementById("error_content").style.display = "block"; //Display Error Message
        }
      }
    }
}
function processingComplete(){	
	document.getElementById("loader").style.display = "none";
	document.getElementById("form_container").style.display = "block";
}
function startProcessing(){	
	document.getElementById("form_container").style.display = "none";
	document.getElementById("loader").style.display = "block";
}
function newSRFlow(){
	console.log('newSRFlow');
	getSRDetailsFromMOS();
	document.getElementById("srStatusSelect").value = "New";
	document.getElementById("saveForm").value = "Create SR";
	document.getElementById("projDiv").style.display = "block";
	document.getElementById("lblSRClose1").style.display = "none";
	document.getElementById("lblSRUpd1").style.display = "block";
	document.getElementById("initialize_user").style.display = "none";
	
	status_open = "N";
	status_new = "Y";	
}
/*MOS Details*/
function getSRDetailsFromMOS(){
	console.log('getSRDetailsFromMOS');
	startProcessing();
	var emaiStored = localStorage.getItem("ssoEm");
	if(emaiStored != null){
		var xhr = new XMLHttpRequest();
		var file = "https://support.us.oracle.com/oip/faces/ListRequest?query=SRNumber%3D%27"+srNumber+"%27&type=SR&sort=%20-SRSubmitDate&listBCId=9381-46803&subject="+emaiStored+"&mode=All&recCountType=NONE&customPreventCache=1526936689409&start=0&count=50";
		console.log('URL' + file);
		xhr.timeout = 5000;
		xhr.open('GET', file, true);
		xhr.send();
		xhr.addEventListener("readystatechange", processRequest, false);
		function processRequest(e) {
		  if (xhr.readyState == 4) {
			if (xhr.status == 200) {
			if(xhr.responseText == "undefined"){
				alert("Undefined Response From MOS, Please Try Again");
			}	
			else{
			  var responseText = JSON.parse(xhr.responseText);
			  var countOfProjects = Object.keys(responseText.items).length;
			  if (countOfProjects > 0) {
				for (var i = 0; i < countOfProjects; i++) {
					document.getElementById("summaryTxt").value = responseText.items[i].summary;
					document.getElementById("srOwner").value = responseText.items[i].owner;
					document.getElementById("element_2").value = responseText.items[i].description;
					csiNum = responseText.items[i].CSI;
					document.getElementById("severity").value = responseText.items[i].severity;
					console.log('csiNum' + csiNum);
					getProjectDetails(); // Get Project Names from Implementation Portal
					processingComplete();
				}
			  } 
			  }	
			} else {
			   document.getElementById("hover_bkgr_fricc_error").style.display = "block";
			}
		  }
		}
	}
}
//Function to fetch Project Name
function getProjectDetails() {
	console.log('getProjectDetails');
	startProcessing();
	var csiNumber = csiNum;
	var url = getProject + csiNumber;
	const xhr = new XMLHttpRequest();
	xhr.timeout = 5000;
	xhr.onreadystatechange = function (e) {
		if (xhr.readyState === 4) {
			if (xhr.status === 200) {
				var responseText = JSON.parse(xhr.responseText);
				var countOfProjects = Object.keys(responseText.items).length;
				if (projName !== "") {
					document.getElementById("projDiv").style.display = "block";
					if (countOfProjects > 0) {
						var catOptions = "";
						for (var i = 0; i < countOfProjects; i++) {
							var option = document.createElement("option");
							option.text = responseText.items[i].projectname;
							option.value = responseText.items[i].projectid;
							option.selected = "selected";
							var select = document.getElementById("projName");
							select.appendChild(option);
						}
					} else {
						proj_available = "N";
						window.alert("No Projects Available, Please Register the customer in Implementation Portal");
					}
				}
			} else {
				window.alert("Error in fetching Projects");
				document.getElementById("hover_bkgr_fricc_error").style.display = "block";
			}
		}
	};
	xhr.ontimeout = function () {
		document.getElementById("hover_bkgr_fricc_error").style.display = "block";
	};
	xhr.open("get", url, true);
	xhr.send();
}
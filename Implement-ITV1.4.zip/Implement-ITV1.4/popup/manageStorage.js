function verifyLocalMemory(){
	
	var emaiStored = localStorage.getItem("ssoEm");
	if(emaiStored == "undefined" || emaiStored == "" || emaiStored == null || emaiStored == "null"){
		initializeFirstLoad();
	}
	else{
		hideMailDiv();
		//initializeFirstLoad();
	}
}
function setEmail(em_text) {
  localStorage.setItem('ssoEm', em_text);
}